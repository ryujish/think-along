export default function Header(){
  return (
    <header className="border-b p-4 font-bold text-green-700">
      Think Along
    </header>
  )
}
