"use client";

import { Sparkles } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-zinc-50">
      {/* Header */}
      <header className="sticky top-0 z-10 flex items-center justify-between border-b border-zinc-200 bg-white px-6 py-4">
        <h1 className="text-xl font-bold tracking-tight text-green-600">
          Think Along
        </h1>

        <div className="h-10 w-10 rounded-full bg-zinc-200" />
      </header>

      <div className="mx-auto flex max-w-3xl flex-col gap-8 px-6 py-10">

        {/* Greeting */}
        <section>
          <h2 className="text-4xl font-bold text-zinc-900">
            Good Morning 👋
          </h2>

          <p className="mt-2 text-zinc-500">
            What would you like to think about today?
          </p>
        </section>

        {/* Prompt */}
        <section className="rounded-3xl bg-white p-6 shadow-sm">
          <textarea
            placeholder="Ask anything..."
            className="h-36 w-full resize-none outline-none placeholder:text-zinc-400"
          />

          <div className="mt-5 flex items-center justify-between">

            <div className="flex gap-3">

              <button className="rounded-full bg-zinc-100 px-4 py-2 text-sm">
                GPT
              </button>

              <button className="rounded-full bg-zinc-100 px-4 py-2 text-sm">
                Claude
              </button>

              <button className="rounded-full bg-zinc-100 px-4 py-2 text-sm">
                Gemini
              </button>

            </div>

            <button className="flex items-center gap-2 rounded-full bg-green-600 px-5 py-2 font-medium text-white transition hover:bg-green-700">
              <Sparkles size={18} />
              Think
            </button>

          </div>
        </section>

        {/* Continue */}
        <section>

          <h3 className="mb-4 text-xl font-semibold">
            Continue
          </h3>

          <div className="rounded-2xl bg-white p-5 shadow-sm">

            <div className="font-semibold">
              AI Startup Idea
            </div>

            <div className="mt-2 text-sm text-zinc-500">
              Last edited 2 hours ago
            </div>

          </div>

        </section>

      </div>
    </main>
  );
}